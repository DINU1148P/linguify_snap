
package app.lovable.a73cf0f99fbe4d13a5384a7cb3d8f58d;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

